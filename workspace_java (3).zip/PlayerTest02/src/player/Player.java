package player;

public interface Player {
	
	void play();
	void stop();

}
