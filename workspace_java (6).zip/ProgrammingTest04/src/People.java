
public class People {
	private String name;
	private String gender;
	
	public People(String name, String gender) {
		this.name = name;
		this.gender = gender;
	}
	
	// getter
	public String getName() {
		return name;
	}
	
	public String getGender() {
		return gender;
	}
	
	// setter
	public void setName(String name) {
		this.name = name;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String toString() {
		return ("�� : �̸�(" + name + "), ����(" + gender + ")");
	}
	
}
