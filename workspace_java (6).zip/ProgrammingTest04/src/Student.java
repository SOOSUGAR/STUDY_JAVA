

public class Student extends People {
	
	private String sno;
	
	public Student(String name, String gender, String sno) {
		super(name, gender);
		this.sno = sno;
	}
	
	public String getSno() {
		return sno;
	}
	
	public void setSno(String sno) {
		this.sno = sno;
	}
	
	public String toString() {
		return super.toString() + ", �й�(" + sno + ")";
	}
	
}
