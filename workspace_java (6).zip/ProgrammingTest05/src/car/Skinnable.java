package car;

public interface Skinnable {
	
	int RED = 1;
	int BLUE = 2;
	int BLACK = 3;
	int WHITE = 4;
	
	void changeSkin(int skin);

}
