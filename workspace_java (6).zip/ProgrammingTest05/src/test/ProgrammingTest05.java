package test;

import car.Car;
import car.SUV;
import car.Sedan;
import car.SuperCar;
import car.Truck;

public class ProgrammingTest05 {
	public static void main(String[] args) {
		Car[] car = new Car[5];
		car[0] = new Sedan("�׷���");
		car[1] = new SUV("�縮���̵�");
		car[2] = new Truck("����");
		car[3] = new SuperCar("���");
		
		
		for(Car a : car) {
			a.run();
			a.stop();
			if(a instanceof Sedan) {
				((Sedan)a).sound(); 
			} else if(a instanceof SuperCar) {
				((SuperCar)a).turbo();
				((SuperCar)a).changeSkin(1);
			} else if(a instanceof Truck) {
				((Truck)a).load();
			} else if(a instanceof SUV) {
				((SUV)a).safe();
			} 
			System.out.println();
		}
		
		
		
	}

}
