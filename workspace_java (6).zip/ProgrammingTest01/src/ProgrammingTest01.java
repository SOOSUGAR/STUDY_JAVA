import java.util.Scanner;

public class ProgrammingTest01 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("��� �Է� : ");
		int a = sc.nextInt();
		System.out.print("���� �Է� : ");
		int b = sc.nextInt();
		
		for(int i = 0; i < a; i++) {
			for(int j = 0; j < a-i-1; j++) {
				System.out.print(" ");
			}
			for(int j = 0; j < b; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		
		
	}
}
