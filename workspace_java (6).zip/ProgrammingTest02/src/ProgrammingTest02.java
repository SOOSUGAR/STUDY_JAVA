import java.util.Scanner;

public class ProgrammingTest02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int sum = 0;
		double ave = 0.0;
		String grades = "";
		
		System.out.print("�л��� �Է� : ");
		int n = sc.nextInt();
		int[] scores = new int[n];
		
		for(int i = 0; i < scores.length; i++) {
			System.out.print(i+1 + "��° �л� ���� �Է� : ");
			scores[i] = sc.nextInt();
			sum += scores[i];
		}
		ave = (double)sum/n;
		
		switch((int)ave/10) {
		case 10: case 9: grades = "A"; break;
		case 8: grades = "B"; break;
		case 7: grades = "C"; break;
		case 6: grades = "D"; break;
		default: grades = "F"; break;
		}
		
		System.out.printf("����: %d\n���: %.2f\n����: %s ", sum, ave, grades);
		
		
	}

}
