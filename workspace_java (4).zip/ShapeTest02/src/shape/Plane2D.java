package shape;

public interface Plane2D {
	
	int getArea();
	
	}
