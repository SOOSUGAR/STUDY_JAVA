package wearable;

public interface Color {
	
	int RED = 1; // public static final ����
	int GREEN = 2;
	int BLUE = 3;
	int BLACK = 4;
	int WHITE = 5;
	
	void changeColor(int color); // public abstract ����

}
